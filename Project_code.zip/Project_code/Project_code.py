import pygame

# import the scene class
from scene import Scene

from lightSource import LightSource

from blender import load_obj_file

from BaseModel import DrawModelFromMesh

from shaders import *

# from ShadowMapping import *

# from sphereModel import Sphere

# from skyBox import *

# from environmentMapping import *


class StreetScene(Scene):
    def __init__(self):
        Scene.__init__(self)

        self.light = LightSource(self, position=[0., 1., 0.])

        # self.shaders = 'phong'

        # For shadow map rendering
        # self.shadows = ShadowMap(light = self.light)
        # self.show_shadow_map = ShowTexture(self, self.shadows)

        self.camera.update()

        scene_model = load_obj_file('models/Scene_model.obj')
        self.add_models_list(
            [DrawModelFromMesh(scene=self, M=np.matmul(translationMatrix([0,0,20]),scaleMatrix([0.5,0.5,0.5])), mesh=mesh,
            shader=FlatShader()) for mesh in scene_model]
        )
        # For shader, if environment mapping were enabled, EnvironmentShader would have been used

        # Drawing a skyBox for visualising the horizon
        # self.skybox = SkyBox(scene = self)

        # self.show_light = DrawModelFromMesh(scene=self, M=poseMatrix(position=self.light.position,scale=0.1),
        # mesh=Sphere(material=Material(Ka=[10, 10, 10])), shader=FlatShader())

        #self.environment = EnvironmentMappingTexture(width=400, height=400)

        # car01 = load_obj_file('Models/car.obj')
        # self.car01 = DrawModelFromMesh(scene=self, M=np.matmul(translationMatrix([1,1,0]),scaleMatrix([0.1,0.1,0.1])), mesh=car01[0],
        # shader = EnvironmentShader(map=self.environment))

        # car02 = load_obj_file('Models/car.obj')
        # self.car02 = DrawModelFromMesh(scene=self, M=np.matmul(translationMatrix([1,12,0]),scaleMatrix([0.1,0.1,0.1])), mesh=car02[0],
        # shader = EnvironmentShader(map=self.environment))

        # car03 = load_obj_file('Models/car.obj')
        # self.car03 = DrawModelFromMesh(scene=self, M=np.matmul(translationMatrix([1,56,0]),scaleMatrix([0.1,0.1,0.1])), mesh=car03[0],
        # shader = EnvironmentShader(map=self.environment))

        # Environment box for reflections
        # self.envbox = EnvironmentBox(scene=self)

    # def draw_shadow_map(self):
    #     # Firstly, clear the scene, clear the depth buffer - to handle occlusions
    #     glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        # Also all car models
        # for model in self.car01:
        #     model.draw()
        
        # for model in self.car02:
        #     model.draw()
        
        # for model in self.car03:
        #     model.draw()
    
    # def draw_reflections(self):
    #     self.skybox.draw()  # For having something to reflect on the objects

        # In this case, the cars...
        # for model in self.car01:
        #     model.draw()

        # for model in self.car02:
        #     model.draw()

        # for model in self.car03:
        #     model.draw()


    # def keyboard(self, event):
    #     '''
    #     Process additional keyboard events for this demo.
    #     '''
    #     Scene.keyboard(self, event)

    #     if event.key == pygame.K_1:
    #         print('--> using Flat shading')
    #         self.bunny.use_textures = True
    #         self.bunny.bind_shader('flat')


    #     elif event.key == pygame.K_2:
    #         print('--> using Texture shading')
    #         self.bunny.bind_shader('texture')


    def draw(self):
        '''
        Draw all models in the scene
        :return: None
        '''

        # first we need to clear the scene, we also clear the depth buffer to handle occlusions
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        self.camera.update()

        # Drawing the skybox
        # self.skybox.draw()

        # Ignoring the reflective object when rendering
        # if not framebuffer:
        #     #glEnable(GL_BLEND)
        #     #glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        #     #self.envbox.draw()
        #     #self.environment.update(self)
        #     #self.envbox.draw()

        #     self.environment.update(self)

            # self.car01.draw()
            # self.car02.draw()
            # self.car03.draw()

            # self.show_shadow_map.draw()

        # then we loop over all models in the list and draw them
        for model in self.models:
            model.draw()
        

        # once we are done drawing, we display the scene
        # Note that here we use double buffering to avoid artefacts:
        # we draw on a different buffer than the one we display,
        # and flip the two buffers once we are done drawing.
        pygame.display.flip()


if __name__ == '__main__':
    # initialises the scene object
    # scene = Scene(shaders='gouraud')
    scene = StreetScene()

    # starts drawing the scene
    scene.run()
